package com.example.liquidglass

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.graphics.RenderEffect
import android.graphics.Shader
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var content: LinearLayout
    private lateinit var modeButton: TextView
    private lateinit var status: TextView
    private var expanded = true
    private var losers = false
    private var tickers: List<MarketTicker> = emptyList()
    private var refreshing = false
    private val executor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
        executor.execute { refresh() }
        executor.scheduleAtFixedRate({ refresh() }, 30, 30, TimeUnit.SECONDS)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("market_widget", "行情悬浮窗", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "market_widget")
                .setContentTitle("Binance Liquid Glass")
                .setContentText("U 本位合约行情悬浮窗运行中")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("Binance Liquid Glass")
                .setContentText("行情悬浮窗运行中").setSmallIcon(android.R.drawable.ic_menu_view).build()
        }
    }

    private fun glass(bg: Int = 0xBDEEF4FA.toInt()): GradientDrawable =
        GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(28).toFloat()
            setStroke(dp(1), 0xBFFFFFFF.toInt())
        }

    private fun text(value: String, size: Float, color: Int = Color.BLACK, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass()
            setPadding(dp(10), dp(9), dp(10), dp(9))
            elevation = dp(14).toFloat()
        }
        if (Build.VERSION.SDK_INT >= 31) {
            root.setRenderEffect(RenderEffect.createBlurEffect(12f, 12f, Shader.TileMode.CLAMP))
        }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = text("BINANCE  ·  U 本位", 14f, Color.rgb(24, 35, 50), true)
        header.addView(brand, LinearLayout.LayoutParams(0, dp(42), 1f))
        status = text("● 连接中", 11f, Color.rgb(30, 145, 100))
        header.addView(status)
        modeButton = text("  ▢  ", 22f, Color.BLACK, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { expanded = !expanded; render() }
        }
        header.addView(modeButton, LinearLayout.LayoutParams(dp(44), dp(42)))
        root.addView(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val gain = text("涨幅榜", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(0xFF2378D5.toInt(), 24)
            setOnClickListener { losers = false; render() }
        }
        val fall = text("跌幅榜", 13f, Color.DKGRAY, true).apply {
            gravity = Gravity.CENTER
            background = rounded(0x22FFFFFF, 24)
            setOnClickListener { losers = true; render() }
        }
        tabs.addView(gain, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(5) })
        tabs.addView(fall, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        root.addView(tabs)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content)
        val footer = text("数据：Binance Futures 公共行情  ·  30 秒刷新", 10f, 0xFF596574.toInt())
        footer.gravity = Gravity.CENTER
        root.addView(footer)

        params = WindowManager.LayoutParams(
            dp(340), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(120)
        }
        installDrag(header)
        wm.addView(root, params)
        render()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun installDrag(handle: View) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(root, params) }
                    true
                }
                else -> false
            }
        }
    }

    private fun refresh() {
        if (refreshing) return
        refreshing = true
        try {
            val data = BinanceApi.fetch()
            runOnMain {
                tickers = data
                status.text = "● 更新成功"
                render()
            }
        } catch (e: Exception) {
            runOnMain {
                status.text = "● 网络异常"
                Toast.makeText(this, "行情获取失败：${e.message ?: "请检查网络"}", Toast.LENGTH_SHORT).show()
            }
        } finally {
            refreshing = false
        }
    }

    private fun runOnMain(block: () -> Unit) {
        android.os.Handler(mainLooper).post(block)
    }

    private fun render() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        modeButton.text = if (expanded) "  ▱  " else "  ⤢  "
        val list = if (losers) tickers.sortedBy { it.changePercent }.take(8)
                   else tickers.sortedByDescending { it.changePercent }.take(8)
        if (!expanded) {
            root.layoutParams = root.layoutParams.apply { width = dp(205) }
            runCatching { wm.updateViewLayout(root, params) }
            val line = list.take(3).joinToString("   ") {
                "${it.displaySymbol} ${String.format("%.1f%%", it.changePercent)}"
            }
            content.addView(text(if (list.isEmpty()) "正在获取行情…" else line, 11f, Color.rgb(28, 42, 58), true))
            return
        }
        root.layoutParams = root.layoutParams.apply { width = dp(340) }
        runCatching { wm.updateViewLayout(root, params) }
        val heading = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        heading.addView(text("交易对", 10f, 0xFF66717E.toInt(), true), LinearLayout.LayoutParams(0, dp(28), 1f))
        heading.addView(text("最新价", 10f, 0xFF66717E.toInt(), true), LinearLayout.LayoutParams(dp(82), dp(28)))
        heading.addView(text("24H", 10f, 0xFF66717E.toInt(), true), LinearLayout.LayoutParams(dp(72), dp(28)).apply { gravity = Gravity.RIGHT })
        content.addView(heading)
        if (list.isEmpty()) {
            content.addView(text("正在获取 Binance 合约行情…", 13f, Color.DKGRAY))
        } else {
            list.forEachIndexed { index, item ->
                val row = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(5), 0, dp(5), 0)
                    background = rounded(if (index % 2 == 0) 0x35FFFFFF else 0x12FFFFFF, 12)
                    setOnClickListener {
                        val url = "https://www.binance.com/en/futures/${item.symbol}"
                        startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
                row.addView(text("${index + 1}. ${item.displaySymbol}", 12f, Color.rgb(24, 36, 50), true),
                    LinearLayout.LayoutParams(0, dp(39), 1f))
                row.addView(text(item.lastPrice, 10f, Color.rgb(45, 55, 65)),
                    LinearLayout.LayoutParams(dp(82), dp(39)))
                val positive = item.changePercent >= 0
                val pct = text(String.format("%+.2f%%", item.changePercent), 11f,
                    if (positive) 0xFF079968.toInt() else 0xFFE14B58.toInt(), true)
                pct.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                row.addView(pct, LinearLayout.LayoutParams(dp(72), dp(39)))
                content.addView(row)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        executor.shutdownNow()
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
