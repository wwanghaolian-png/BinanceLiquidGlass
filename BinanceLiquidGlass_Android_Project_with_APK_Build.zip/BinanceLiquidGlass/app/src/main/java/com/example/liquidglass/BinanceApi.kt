package com.example.liquidglass

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object BinanceApi {
    // Public USDⓈ-M Futures market data. No API key or account permission required.
    private const val ENDPOINT = "https://fapi.binance.com/fapi/v1/ticker/24hr"

    fun fetch(): List<MarketTicker> {
        val connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Binance API HTTP ${connection.responseCode}")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONArray(body)
            val result = ArrayList<MarketTicker>()
            for (i in 0 until json.length()) {
                val item = json.getJSONObject(i)
                val symbol = item.optString("symbol")
                // Keep active-looking USDT-margined contracts; exclude delivery contracts.
                if (!symbol.endsWith("USDT")) continue
                val change = item.optString("priceChangePercent").toDoubleOrNull() ?: continue
                val price = item.optString("lastPrice")
                val volume = item.optString("quoteVolume").toDoubleOrNull() ?: 0.0
                result.add(MarketTicker(symbol, price, change, volume))
            }
            return result
        } finally {
            connection.disconnect()
        }
    }

    fun money(value: Double): String = when {
        value >= 1_000_000_000 -> String.format(Locale.US, "%.2fB", value / 1_000_000_000)
        value >= 1_000_000 -> String.format(Locale.US, "%.2fM", value / 1_000_000)
        value >= 1_000 -> String.format(Locale.US, "%.1fK", value / 1_000)
        else -> String.format(Locale.US, "%.0f", value)
    }
}
