package com.example.liquidglass

data class MarketTicker(
    val symbol: String,
    val lastPrice: String,
    val changePercent: Double,
    val quoteVolume: Double
) {
    val displaySymbol: String get() = symbol.removeSuffix("USDT")
}
