package com.example.liquidglass

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (22 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(17, 21, 29))
        }
        val title = TextView(this).apply {
            text = "BINANCE  ·  LIQUID GLASS"
            textSize = 22f
            setTextColor(Color.WHITE)
        }
        val desc = TextView(this).apply {
            text = "\nU 本位合约  ·  24H 涨跌幅榜\n每 30 秒自动刷新\n\n悬浮窗支持拖动、展开和胶囊模式。"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        }
        val start = Button(this).apply {
            text = "开启行情悬浮窗"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
                    }
                    startOverlay()
                }
            }
        }
        val stop = Button(this).apply {
            text = "关闭悬浮窗"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        layout.addView(title)
        layout.addView(desc)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && intent.getBooleanExtra("start_overlay", false)) {
            startOverlay()
            intent.removeExtra("start_overlay")
        }
    }

    private fun startOverlay() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }
}
