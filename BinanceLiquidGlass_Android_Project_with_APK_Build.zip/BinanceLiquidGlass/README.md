# Binance Liquid Glass（Android）

独立 Android Studio 项目：Binance USDⓈ-M Futures 24 小时涨跌幅悬浮窗。

## 功能
- 读取 Binance Futures 公共接口 `https://fapi.binance.com/fapi/v1/ticker/24hr`
- 每 30 秒刷新一次
- 涨幅榜 / 跌幅榜切换
- 展开面板 / 紧凑胶囊两种模式
- 顶栏拖动悬浮窗
- 点击交易对打开 Binance Futures 网页
- 不需要 API Key，不请求账户、交易或提币权限

## 构建
1. 使用 Android Studio 打开项目根目录。
2. 等待 Gradle Sync。
3. 连接 Android 设备，运行 `app`。
4. 在应用内点击“开启行情悬浮窗”。
5. 按系统提示授予“显示在其他应用上层”权限。
6. Android 13 及以上允许通知，以便前台服务持续运行。

## 注意
- 需要可访问 Binance API 的网络环境；部分地区或网络可能无法访问。
- 这是行情监控工具，不提供交易建议。
- 当前版本为可构建的基础 MVP；液态玻璃模糊在 Android 12+ 使用 RenderEffect，旧系统使用半透明磨砂风格。
- 真实运行前应在目标手机上验证系统悬浮窗权限、电池优化和厂商后台管理策略。

## 云端构建 APK
本项目包含 GitHub Actions 工作流 `.github/workflows/build-apk.yml`。将项目完整上传到自己的 GitHub 仓库后，在 Actions 页面运行 **Build Android APK**。成功后从运行记录的 Artifacts 下载 `BinanceLiquidGlass-debug-apk`，解压得到 `app-debug.apk`。
